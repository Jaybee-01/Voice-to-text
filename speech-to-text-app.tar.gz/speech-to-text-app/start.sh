#!/bin/bash

echo "======================================"
echo "Speech-to-Text App Setup"
echo "======================================"
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 is not installed. Please install Python 3.8 or higher."
    exit 1
fi

echo "✅ Python3 found: $(python3 --version)"

# Check if FFmpeg is installed
if ! command -v ffmpeg &> /dev/null; then
    echo "⚠️  FFmpeg is not installed."
    echo "Please install FFmpeg:"
    echo "  - Mac: brew install ffmpeg"
    echo "  - Linux: sudo apt install ffmpeg"
    echo "  - Windows: choco install ffmpeg"
    exit 1
fi

echo "✅ FFmpeg found"
echo ""

# Setup backend
echo "Setting up backend..."
cd backend

# Create virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
source venv/bin/activate

# Install requirements
echo "Installing Python dependencies..."
pip install -q --upgrade pip
pip install -q -r requirements.txt

echo "✅ Backend setup complete!"
echo ""
echo "======================================"
echo "Starting Backend Server..."
echo "======================================"
python app.py &
BACKEND_PID=$!

echo "Backend running on http://localhost:5000 (PID: $BACKEND_PID)"
echo ""

# Give backend time to start
sleep 3

# Start frontend
echo "======================================"
echo "Starting Frontend Server..."
echo "======================================"
cd ../frontend

# Check if Python http.server is available
python3 -m http.server 8000 &
FRONTEND_PID=$!

echo "Frontend running on http://localhost:8000 (PID: $FRONTEND_PID)"
echo ""
echo "======================================"
echo "✨ Application is ready!"
echo "======================================"
echo ""
echo "📱 Open your browser and go to:"
echo "   http://localhost:8000"
echo ""
echo "To stop the servers, press Ctrl+C"
echo ""

# Wait for user interrupt
wait
