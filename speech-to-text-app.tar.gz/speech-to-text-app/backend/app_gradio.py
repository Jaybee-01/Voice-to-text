import gradio as gr
import whisper
import tempfile
import os

# Load Whisper model
print("Loading Whisper model...")
model = whisper.load_model("base")
print("Model loaded successfully!")

def transcribe_audio(audio_file, language):
    """
    Transcribe audio file using Whisper
    
    Args:
        audio_file: Path to audio file or tuple (sample_rate, audio_data)
        language: Language code (en, es, fr, de, ha, yo, ig, etc.)
    
    Returns:
        Transcription text
    """
    try:
        if audio_file is None:
            return "Please upload an audio file or record audio."
        
        # Handle both file path and audio tuple
        if isinstance(audio_file, tuple):
            # Audio from microphone (sample_rate, audio_data)
            sample_rate, audio_data = audio_file
            # Save to temporary file
            with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as temp_file:
                import scipy.io.wavfile as wavfile
                wavfile.write(temp_file.name, sample_rate, audio_data)
                audio_path = temp_file.name
        else:
            # Audio file path
            audio_path = audio_file
        
        # Transcribe
        result = model.transcribe(audio_path, language=language)
        
        # Clean up temp file if created
        if isinstance(audio_file, tuple) and os.path.exists(audio_path):
            os.unlink(audio_path)
        
        return result["text"]
    
    except Exception as e:
        return f"Error during transcription: {str(e)}"

# Language options
languages = [
    ("English", "en"),
    ("Spanish", "es"),
    ("French", "fr"),
    ("German", "de"),
    ("Hausa", "ha"),
    ("Yoruba", "yo"),
    ("Igbo", "ig"),
    ("Portuguese", "pt"),
    ("Italian", "it"),
    ("Japanese", "ja"),
    ("Chinese", "zh"),
    ("Arabic", "ar"),
    ("Hindi", "hi"),
    ("Russian", "ru"),
]

# Create Gradio interface
with gr.Blocks(title="Speech-to-Text Transcription") as demo:
    gr.Markdown("# 🎤 Voice-to-Text Transcription")
    gr.Markdown("### By Abdulbasit Yusuf")
    gr.Markdown("Upload an audio file or record your voice to get a transcription.")
    
    with gr.Row():
        language = gr.Dropdown(
            choices=languages,
            value="en",
            label="Select Language",
            info="Choose the language of your audio"
        )
    
    with gr.Tab("Upload Audio"):
        audio_upload = gr.Audio(
            sources=["upload"],
            type="filepath",
            label="Upload Audio File"
        )
        transcribe_upload_btn = gr.Button("Transcribe Upload", variant="primary")
    
    with gr.Tab("Record Audio"):
        audio_record = gr.Audio(
            sources=["microphone"],
            type="filepath",
            label="Record Your Voice"
        )
        transcribe_record_btn = gr.Button("Transcribe Recording", variant="primary")
    
    output = gr.Textbox(
        label="Transcription",
        placeholder="Your transcription will appear here...",
        lines=10
    )
    
    # Event handlers
    transcribe_upload_btn.click(
        fn=transcribe_audio,
        inputs=[audio_upload, language],
        outputs=output
    )
    
    transcribe_record_btn.click(
        fn=transcribe_audio,
        inputs=[audio_record, language],
        outputs=output
    )
    
    gr.Markdown("---")
    gr.Markdown("### Features")
    gr.Markdown("✅ Multiple language support | ✅ Upload or record | ✅ Powered by OpenAI Whisper")

# Launch the app
if __name__ == "__main__":
    demo.launch(
        server_name="0.0.0.0",
        server_port=7860,
        share=False
    )
